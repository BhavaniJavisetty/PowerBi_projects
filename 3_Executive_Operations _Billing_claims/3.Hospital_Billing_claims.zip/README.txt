HOSPITAL BILLING & CLAIMS OPTIMIZATION — POWER BI COMPLETE DATASET
Synthetic clean relational dataset for a 4-page Power BI client demo.
Reference date: 2026-09-11
Coverage: 2025-03-11 to 2026-09-11 (18 months)

FILES
patients.csv = 5,000 unique patients
visits.csv = 10,000 visits
billing.csv = 10,000 billing records
claims.csv = 6,427 claims
calendar.csv = date dimension
data_dictionary.csv = field definitions
data_quality_report.csv = validation checks

RELATIONSHIPS
Patients[Patient_ID] 1 -> * Visits[Patient_ID]
Visits[Visit_ID] 1 -> 1 Billing[Visit_ID]
Billing[Bill_ID] 1 -> * Claims[Bill_ID]
Calendar[Date] 1 -> * Billing[Billing_Date]

REALISM
ICU and Surgery have higher average billing.
Claims denial rate = 11.75% (target 8–15%).
Unbilled records contain realistic delay reasons.
All patient names are synthetic.
Data ends on 2026-09-11 for current-period demos.

4 POWER BI PAGES
1 Financial Health & Revenue Overview
2 Revenue Leakage Analytics
3 Claims Rejection Tracker
4 Executive Operations Overview

PAGE 4 SUPPORT
Daily patient inflow: Visit_ID by Admission_DateTime
Emergency intake: Emergency_Flag / Visit_Type
Treatment time: Treatment_Start to Treatment_End
Wait time: Wait_Time_Minutes
Operational slicing: Department, Ward, Bed_ID, Visit_Type

LIVE DATA NOTE
This is synthetic, NOT a real hospital live feed. It is refresh-ready and current-date anchored for a realistic demo.
For true live data, connect these same tables to an authorized hospital HIS/EMR/SQL/API source.
Use DAX TODAY() for dynamic Today/This Week/This Month measures in Power BI.
